﻿namespace FootballManager.ViewModels.Users
{
    public class LoginFormModel
    {
        public string Username { get; set; }

        public string Password { get; set; }
    }
}
