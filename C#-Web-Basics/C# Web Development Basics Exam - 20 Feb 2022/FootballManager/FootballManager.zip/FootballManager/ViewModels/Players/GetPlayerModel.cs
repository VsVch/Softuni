﻿namespace FootballManager.ViewModels.Players
{
    public class GetPlayerModel
    {
    }
}
