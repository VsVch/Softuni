﻿using Bakery.Models.BakedFoods;
using Bakery.Models.BakedFoods.Contracts;
using Bakery.Models.Drinks;
using Bakery.Models.Drinks.Contracts;
using Bakery.Models.Tables.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bakery.Models.Tables
{
    public class Table : ITable
    {
        private int tableNumber;
        private int capacity;
        private int numberOfPeople;
        private readonly List<IBakedFood> foods;
        private readonly List<IDrink> drinks;

        public Table(int tableNumber, int capacity, decimal pricePerPerson)
        {
            this.TableNumber = tableNumber;
            this.Capacity = capacity;
            this.PricePerPerson = pricePerPerson;
            foods = new List<IBakedFood>();
            drinks = new List<IDrink>();
        }

        public int TableNumber { get; private set; }

        public int Capacity
        {
            get => this.capacity;
            private set
            {
                if (value <= 0)
                {
                    throw new ArgumentException("Capacity has to be greater than 0");
                }
                this.capacity = value;
            }
        }

        public int NumberOfPeople
        {
            get => this.numberOfPeople;
            private set
            {
                if (value <= 0)
                {
                    throw new ArgumentException("Cannot place zero or less people!");
                }
                this.numberOfPeople = value;
            }
        }        

        public decimal PricePerPerson { get; private set; }

        public bool IsReserved { get; set; } = false;

        public decimal Price => numberOfPeople * PricePerPerson;

        public void Clear()
        {
            foods.Clear();
            drinks.Clear();
            IsReserved = false;
            numberOfPeople = 0;
        }

        public decimal GetBill()
        {
            decimal foodCost = foods.Select(f => f.Price).Sum();
            decimal drinkCost = drinks.Select(f => f.Price).Sum();

            return foodCost + drinkCost;
        }

        public string GetFreeTableInfo()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"Table: {this.TableNumber}");
            sb.AppendLine($"Type: {this.GetType().Name}");
            sb.AppendLine($"Capacity: {this.Capacity}");
            sb.AppendLine($"Price per Person: {this.PricePerPerson:f2}");

            return sb.ToString().TrimEnd();
        }

        public void OrderDrink(IDrink drink)
        {

            if (drink.GetType().Name == nameof(Water))
            {
                drink = new Water(drink.Name,drink.Portion, drink.Brand);
            }
            else if (drink.GetType().Name == nameof(Tea))
            {
                drink = new Tea(drink.Name, drink.Portion, drink.Brand);
            }

            drinks.Add(drink);
        }

        public void OrderFood(IBakedFood food)
        {
            
            if (food.GetType().Name == nameof(Bread))
            {
                food = new Bread(food.Name, food.Price);
            }
            else if (food.GetType().Name == nameof(Cake))
            {
                food = new Cake(food.Name, food.Price);
            }

            foods.Add(food);
        }

        public void Reserve(int numberOfPeople)
        {
            // error 100 %

            this.NumberOfPeople = numberOfPeople;

            IsReserved = true;
        }
    }
}
